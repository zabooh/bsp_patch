#!/bin/sh
echo "Start Custom-Configuration..." > /tmp/bootlog.txt

ethtool --set-plca-cfg eth2 enable on node-id 0 node-cnt 8

ip link set eth0 down
ip link set eth1 down
ip link set eth2 down

ip addr flush dev eth0
ip addr flush dev eth1
ip addr flush dev eth2

ip addr add 169.254.35.112/16 dev eth0
ip addr add 192.168.178.20/24 dev eth1
ip addr add 192.168.0.5/24 dev eth2

ip link set eth0 up
ip link set eth1 up
ip link set eth2 up

