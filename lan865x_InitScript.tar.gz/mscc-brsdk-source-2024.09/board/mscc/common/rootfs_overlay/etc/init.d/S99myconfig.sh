#!/bin/sh
echo "Start Custom-Configuration..." > /tmp/bootlog.txt
# Sample Configuration

ethtool --set-plca-cfg eth2 enable on node-id 0 node-cnt 8
ip addr add dev eth2 169.254.35.112/16
ip link set eth2 up

ip addr add dev eth0 169.254.35.110/16
ip link set eth0 up



